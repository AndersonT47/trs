import styled, { css } from 'styled-components';

interface INewResquestParams { }

export const ContainerWrapper = styled.div``;