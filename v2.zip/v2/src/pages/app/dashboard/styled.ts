import styled from "styled-components";

export const MainContainer = styled.div`
  display: flex;
  min-height: 100vh;
  background-color: #f7f7f8;
`;
