export interface IAuthParams {
  userName: string;
  password: string;
}
