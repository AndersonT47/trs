export const apiPathAddress = {
  feeManagement: "/v1/conductor/fee",
  uploadDocuments: "/v1/file",
  customerSearch: "/customer/v1",
  feeCaseCreate: "/v1/fee/case",
  userAuthentication: "/user-management/v1/authentication",
  conductorFeeManagement: "",
  conductorCustomer: "/v1/conductor/customer",
};

export const apiConstants = {
  realm: "SNB-Internal",
  profile: "employee",
};
