import styled from "styled-components";

interface IPDFViewerParams {}

export const ContainerWrapper = styled.div`
  width: 100%;
  height: 100%;
`;
// export const Iframe = styled.iframe`
//   width: 100%;
//   height: 500px;
//   border: 0px;
// `;
