export const SelectStatus = [
  {
    _id: "",
    text: "All",
    value: "All",
  },
  {
    _id: 1,
    text: "Pending",
    value: "Pending",
  },
  {
    _id: 2,
    text: "Completed",
    value: "Completed",
  },
];
