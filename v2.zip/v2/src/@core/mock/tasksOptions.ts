export const SelectTasks = [
  {
    _id: "",
    text: "All",
    value: "All",
  },
  {
    _id: 2,
    text: "Fee Management",
    value: "Fee Management",
  },
  {
    _id: 3,
    text: "Cash Reverse - New",
    value: "Cash Reverse - New",
  },
  {
    _id: 4,
    text: "Cash Reverse - Increase",
    value: "Cash Reverse - Increase",
  },
  {
    _id: 5,
    text: "Compliance - Communication",
    value: "Compliance - Communication",
  },
  {
    _id: 6,
    text: "Compliance - Transactions",
    value: "Compliance - Transactions",
  },
  {
    _id: 7,
    text: "Credit Card",
    value: "Credit Card",
  },
  {
    _id: 8,
    text: "ACAT",
    value: "ACAT",
  },
  {
    _id: 9,
    text: "FIN - Cash Reconciliation",
    value: "FIN - Cash Reconciliation",
  },
  {
    _id: 10,
    text: "HR - Access Request",
    value: "HR - Access Request",
  },
  {
    _id: 11,
    text: "JSAM Account Management",
    value: "JSAM Account Management",
  },
  {
    _id: 12,
    text: "Loan - New",
    value: "Loan - New",
  },
  {
    _id: 13,
    text: "Loan - Increase",
    value: "Loan - Increase",
  },
  {
    _id: 14,
    text: "Loan - Pay",
    value: "Loan - Pay",
  },
  {
    _id: 15,
    text: "Security - Internal Transfer",
    value: "Security - Internal Transfer",
  },
  {
    _id: 16,
    text: "Security - External Delivery",
    value: "Security - External Delivery",
  },
  {
    _id: 17,
    text: "Security - External Receive",
    value: "Security - External Receive",
  },
  {
    _id: 18,
    text: "Security - Same CIF Equities",
    value: "Security - Same CIF Equities",
  },
  {
    _id: 19,
    text: "Travel Request",
    value: "Travel Request",
  },
  {
    _id: 20,
    text: "Worthless Shares - Transfer",
    value: "Worthless Shares - Transfer",
  },
];
