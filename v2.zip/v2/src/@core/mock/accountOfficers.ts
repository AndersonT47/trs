export const AccountOfficers = [
  {
    _id: 1,
    text: "Poppie Reese",
    value: "Poppie Reese",
  },
  {
    _id: 2,
    text: "Lilian Rollins",
    value: "Lilian Rollins",
  },
  {
    _id: 3,
    text: "Lester Melton",
    value: "Lester Melton",
  },
  {
    _id: 4,
    text: "Faye Wright",
    value: "Faye Wright",
  },
  {
    _id: 5,
    text: "Kezia Dorsey",
    value: "Kezia Dorsey",
  },
  {
    _id: 6,
    text: "Siena Nixon",
    value: "Siena Nixon",
  },
  {
    _id: 7,
    text: "Kiran Logan",
    value: "Kiran Logan",
  },
  {
    _id: 8,
    text: "Lyla Mercado",
    value: "Lyla Mercado",
  },
  {
    _id: 9,
    text: "Kirsty Carey",
    value: "Kirsty Carey",
  },
  {
    _id: 10,
    text: "Siena Nixon",
    value: "Siena Nixon",
  },
];
